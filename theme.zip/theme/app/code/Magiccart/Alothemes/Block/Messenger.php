<?php
/**
 * Magiccart 
 * @category 	Magiccart 
 * @copyright 	Copyright (c) 2014 Magiccart (http://www.magiccart.net/) 
 * @license 	http://www.magiccart.net/license-agreement.html
 * @Author: Magiccart<team.magiccart@gmail.com>
 * @@Create Date: 2019-06-15 00:01:29
 * @@Modify Date: 2019-06-15 00:24:43
 * @@Function:
 */

namespace Magiccart\Alothemes\Block;
 
class Messenger  extends \Magento\Framework\View\Element\Template
{   

}
